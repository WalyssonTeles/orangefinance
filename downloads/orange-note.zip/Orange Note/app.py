import sys

from orange_note.app import main

if __name__ == "__main__":
    sys.exit(main())
