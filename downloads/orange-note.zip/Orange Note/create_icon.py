from struct import pack


def ico_pixel(r, g, b, a=255):
    return bytes((b, g, r, a))


def draw_icon():
    size = 16
    data = bytearray()
    bg = (245, 140, 30)  # orange
    dark = (213, 102, 20)
    white = (255, 255, 255)
    outline = (255, 247, 233)

    # create 16x16 BGRA pixels
    for y in range(size):
        for x in range(size):
            # rounded-square background area with a subtle darker edge
            if x in (0, size - 1) or y in (0, size - 1):
                px = outline
            elif 2 <= x <= 13 and 2 <= y <= 13:
                px = bg
            else:
                px = bg

            # create a notch / letter-like N on the icon
            # vertical bars
            if (x in (3, 12) and 3 <= y <= 12) or (x == 8 and 3 <= y <= 12):
                px = white
            # diagonal from top-left to bottom-right
            if x >= 4 and x <= 10 and y >= 3 and y <= 12:
                if x - 4 == y - 3:
                    px = white
            # right bar
            if x in (11, 12) and 3 <= y <= 12:
                px = white

            # make the icon look more polished
            if x in (1, 14) or y in (1, 14):
                px = dark

            data.extend(ico_pixel(*px, 255))

    # BMP info header (BITMAPINFOHEADER)
    # width, height, planes, bitcount, compression, image size, etc.
    width = height = 16
    dib_size = 40
    size_image = width * height * 4
    bmp = bytearray()
    bmp += pack('<I', dib_size)
    bmp += pack('<i', width)
    bmp += pack('<i', height * 2)
    bmp += pack('<H', 1)
    bmp += pack('<H', 32)
    bmp += pack('<I', 0)
    bmp += pack('<I', size_image)
    bmp += pack('<i', 2835)
    bmp += pack('<i', 2835)
    bmp += pack('<I', 0)
    bmp += pack('<I', 0)

    # ICO file header + icon directory entry
    ico = bytearray()
    ico += b'\x00\x00\x01\x00\x01\x00'
    ico += b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    # Actual structure requires width, height, colors, reserved, planes, bitcount, size, offset
    # We rebuild correctly below.
    ico = bytearray()
    ico += b'\x00\x00'  # reserved
    ico += b'\x01\x00'  # type (ICO)
    ico += b'\x01\x00'  # count

    # directory entry
    ico += bytes([16, 16, 0, 0, 1, 0, 32, 0])
    ico += pack('<I', 40 + size_image)
    ico += pack('<I', 6 + 16)

    # Dib bitmap data
    ico += bmp
    ico += data

    return bytes(ico)


def save_icon(path='orange_note.ico'):
    with open(path, 'wb') as f:
        f.write(draw_icon())
    print(f'Ícone salvo em: {path}')


if __name__ == '__main__':
    save_icon()
