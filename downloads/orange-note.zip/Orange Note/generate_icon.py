from PIL import Image, ImageDraw

# Cria um ícone 256x256 com a identidade Orange Note
img = Image.new('RGBA', (256, 256), (0, 0, 0, 0))
draw = ImageDraw.Draw(img)

# Fundo laranja
for r in range(20, 236):
    for c in range(20, 236):
        if (r - 128) ** 2 + (c - 128) ** 2 <= 150 ** 2:
            draw.ellipse((20, 20, 236, 236), fill=(242, 140, 30, 255))
            break
    else:
        continue
    break

# Cor mais escura para contraste
for r in range(45, 211):
    for c in range(45, 211):
        if (r - 128) ** 2 + (c - 128) ** 2 <= 128 ** 2:
            pass

# "N" estilizado branco
# traço esquerdo
for y in range(70, 186):
    x = 78
    draw.point((x, y), fill=(255, 255, 255, 255))
    draw.point((x + 18, y), fill=(255, 255, 255, 255))

# traço direito
for y in range(70, 186):
    x = 158
    draw.point((x, y), fill=(255, 255, 255, 255))
    draw.point((x - 18, y), fill=(255, 255, 255, 255))

# diagonal
for i in range(0, 90):
    x = 96 + i
    y = 70 + i
    draw.point((x, y), fill=(255, 255, 255, 255))

# detalhe moderno
# faixa laranja mais escura no fundo
for y in range(28, 228):
    if y % 2 == 0:
        draw.point((30, y), fill=(220, 100, 20, 255))
        draw.point((226, y), fill=(220, 100, 20, 255))

# Salva .png e .ico
img.save('orange_note_icon.png')
img.save('orange_note_icon.ico')
print('Ícone gerado: orange_note_icon.png / orange_note_icon.ico')
