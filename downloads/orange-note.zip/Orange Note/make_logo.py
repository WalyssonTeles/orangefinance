from PIL import Image, ImageDraw

W = H = 512

# Base orange rounded square
img = Image.new('RGBA', (W, H), (0, 0, 0, 0))
base = Image.new('RGBA', (W, H), (0, 0, 0, 0))
bd = ImageDraw.Draw(base)
bd.rounded_rectangle((0, 0, W, H), radius=110, fill=(245, 136, 30, 255))
img = Image.alpha_composite(img, base)

# Fruit body
fruit = Image.new('RGBA', (W, H), (0, 0, 0, 0))
fd = ImageDraw.Draw(fruit)
fd.ellipse((80, 90, 430, 430), fill=(245, 140, 32, 255))
fd.ellipse((180, 150, 280, 240), fill=(255, 221, 171, 80))

# Leaf
leaf = Image.new('RGBA', (W, H), (0, 0, 0, 0))
ld = ImageDraw.Draw(leaf)
ld.ellipse((285, 30, 430, 180), fill=(50, 162, 93, 255))
ld.line((355, 60, 350, 170), fill=(255,255,255,200), width=10)
ld.line((345, 170, 332, 225), fill=(120, 80, 25, 255), width=18)
leaf = leaf.rotate(18, expand=True)
fruit = Image.alpha_composite(fruit, leaf)

# Face
fd = ImageDraw.Draw(fruit)
fd.ellipse((165, 225, 205, 260), fill=(86, 53, 19, 255))
fd.ellipse((305, 225, 345, 260), fill=(86, 53, 19, 255))
fd.arc((180, 250, 330, 350), start=20, end=160, fill=(88, 55, 15, 255), width=12)

# Note page
note = Image.new('RGBA', (W, H), (0, 0, 0, 0))
nd = ImageDraw.Draw(note)
nd.rounded_rectangle((155, 275, 380, 430), radius=18, fill=(252, 245, 210, 255))
nd.polygon([(335, 275), (380, 275), (380, 320)], fill=(236, 229, 190, 255))
for y in range(325, 410, 20):
    nd.line((195, y, 325, y), fill=(242, 171, 63, 255), width=8)
nd.line((195, 305, 300, 305), fill=(242, 171, 63, 255), width=8)

# Combine layers
img = Image.alpha_composite(img, fruit)
img = Image.alpha_composite(img, note)
img.save('orange_note_logo.png')
img.save('orange_note_logo.ico')
print('Logo salva em orange_note_logo.png e orange_note_logo.ico')
