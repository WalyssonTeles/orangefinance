import sqlite3
import tempfile
import unittest
from contextlib import closing
from pathlib import Path

from orange_note.storage import (
    NoteRepository,
    color_to_db,
    color_to_key,
    ensure_schema,
    html_to_text,
    normalize_content,
)


class NoteRepositoryTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "notes.db"
        self.repository = NoteRepository(self.db_path)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_create_update_delete_and_reopen(self):
        note_id = self.repository.create_note(
            "Lista", "<p>laranjas</p>", "Pessoal", "#cfeccb"
        )

        reopened = NoteRepository(self.db_path)
        note = reopened.get_note(note_id)
        self.assertEqual(note["title"], "Lista")
        self.assertEqual(note["content"], "<p>laranjas</p>")
        self.assertEqual(note["category"], "Pessoal")

        reopened.update_note(note_id, "Compras", "<b>café</b>", "Geral", "#fdeea0")
        self.assertEqual(reopened.get_note(note_id)["title"], "Compras")
        reopened.delete_note(note_id)
        self.assertIsNone(reopened.get_note(note_id))

    def test_reorder_persists_the_requested_order(self):
        first = self.repository.create_note("Primeira", "")
        second = self.repository.create_note("Segunda", "")
        third = self.repository.create_note("Terceira", "")

        self.repository.reorder_notes([third, first, second])

        self.assertEqual(
            [note["id"] for note in self.repository.list_notes()],
            [third, first, second],
        )

    def test_move_note_places_note_at_requested_position(self):
        first = self.repository.create_note("Primeira", "")
        second = self.repository.create_note("Segunda", "")
        third = self.repository.create_note("Terceira", "")

        self.repository.move_note(third, 0)

        self.assertEqual(
            [note["id"] for note in self.repository.list_notes()],
            [third, first, second],
        )

    def test_reorder_rejects_incomplete_or_duplicate_ids(self):
        first = self.repository.create_note("Primeira", "")
        second = self.repository.create_note("Segunda", "")

        with self.assertRaises(ValueError):
            self.repository.reorder_notes([first, first])
        with self.assertRaises(ValueError):
            self.repository.reorder_notes([first])
        self.assertEqual(
            [note["id"] for note in self.repository.list_notes()], [first, second]
        )

    def test_delete_normalizes_positions(self):
        first = self.repository.create_note("Primeira", "")
        second = self.repository.create_note("Segunda", "")
        third = self.repository.create_note("Terceira", "")
        self.repository.delete_note(second)

        self.assertEqual(
            [(note["id"], note["position"]) for note in self.repository.list_notes()],
            [(first, 0), (third, 1)],
        )

    def test_schema_upgrades_an_older_notes_table(self):
        legacy_path = Path(self.temp_dir.name) / "legacy.db"
        with closing(sqlite3.connect(legacy_path)) as connection:
            with connection:
                connection.execute(
                    "CREATE TABLE notes (id INTEGER PRIMARY KEY, title TEXT, content TEXT)"
                )
                connection.execute(
                    "INSERT INTO notes (title, content) VALUES ('Legada', 'texto')"
                )

        ensure_schema(legacy_path)
        note = NoteRepository(legacy_path).get_note(1)
        self.assertEqual(note["title"], "Legada")
        self.assertIsNotNone(note["created_at"])
        self.assertIsNotNone(note["updated_at"])
        self.assertEqual(note["position"], 0)

    def test_html_preview_extracts_text_and_ignores_markup(self):
        self.assertEqual(
            html_to_text("<h2>Lista</h2><ul><li>laranjas</li><li>café</li></ul>"),
            "Lista laranjas café",
        )

    def test_create_at_top_and_restore_keep_position(self):
        first = self.repository.create_note("Primeira", "")
        top = self.repository.create_note("Topo", "", at_top=True)
        self.assertEqual(
            [note["id"] for note in self.repository.list_notes()], [top, first]
        )

        snapshot = dict(self.repository.get_note(top))
        self.repository.delete_note(top)
        self.repository.restore_note(snapshot)
        restored = [note["id"] for note in self.repository.list_notes()]
        self.assertEqual(restored, [top, first])

    def test_purge_empty_notes_keeps_notes_with_content_or_images(self):
        self.repository.create_note("", "")
        self.repository.create_note("", "<p><br></p>")
        keep_text = self.repository.create_note("", "<p>oi</p>")
        keep_image = self.repository.create_note(
            "", '<p><img src="/attachments/' + "a" * 32 + '.png"></p>'
        )
        self.repository.purge_empty_notes()
        self.assertEqual(
            sorted(note["id"] for note in self.repository.list_notes()),
            sorted([keep_text, keep_image]),
        )

    def test_color_mapping_between_design_keys_and_database(self):
        self.assertEqual(color_to_key("#CFECCB"), "mint")
        self.assertEqual(color_to_key("#fff3e6"), "butter")
        self.assertEqual(color_to_key("blush"), "blush")
        self.assertEqual(color_to_db("peach"), "#ffd9b8")
        self.assertEqual(color_to_db("<script>"), "#fdeea0")

    def test_legacy_content_is_converted_to_simple_html(self):
        self.assertEqual(normalize_content("linha 1\nlinha <2>"), "<p>linha 1</p><p>linha &lt;2&gt;</p>")
        qt_html = "<!DOCTYPE HTML><html><head><style>p{}</style></head><body><p>Olá</p></body></html>"
        self.assertEqual(normalize_content(qt_html), "<p>Olá</p>")
        self.assertEqual(normalize_content("<p>já é html</p>"), "<p>já é html</p>")


if __name__ == "__main__":
    unittest.main()
