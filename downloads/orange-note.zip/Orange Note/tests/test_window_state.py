import json
import tempfile
import unittest
from pathlib import Path

from orange_note.window_state import MIN_SIZE, WindowState

AREA = (0, 0, 1536, 816)


class WindowStateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "window.json"

    def state(self, area=AREA):
        return WindowState(self.path, area)

    def test_first_run_is_centered_horizontally_and_at_top(self):
        x, y, width, height = self.state().geometry()
        self.assertEqual((y, width), (0, 1180))
        self.assertEqual(x, (1536 - 1180) // 2)
        self.assertLessEqual(height, 816)

    def test_saved_size_and_x_are_restored_but_y_is_always_top(self):
        first = self.state()
        first._on_resized(400, 600)
        first._on_moved(300, 250)
        first.save()
        self.assertEqual(self.state().geometry(), (300, 0, 400, 600))

    def test_saved_geometry_is_clamped_to_the_screen(self):
        self.path.write_text(json.dumps({"width": 5000, "height": 5000, "x": 1400}), encoding="utf-8")
        x, y, width, height = self.state().geometry()
        self.assertEqual((width, height, y), (1536, 816, 0))
        self.assertEqual(x, 0)

    def test_tiny_sizes_respect_the_minimum(self):
        self.path.write_text(json.dumps({"width": 10, "height": 10, "x": 0}), encoding="utf-8")
        _, _, width, height = self.state().geometry()
        self.assertEqual((width, height), MIN_SIZE)

    def test_maximized_minimized_and_offscreen_events_are_ignored(self):
        state = self.state()
        state._on_resized(500, 500)
        state._on_moved(100, 10)
        state._on_resized(1536, 816)
        state._on_resized(160, 28)
        state._on_moved(-32000, -32000)
        state._on_moved(-5, -5)
        state.save()
        self.assertEqual(self.state().geometry(), (100, 0, 500, 500))

    def test_corrupt_file_falls_back_to_defaults(self):
        self.path.write_text("{não é json", encoding="utf-8")
        self.assertEqual(self.state().geometry()[1:3], (0, 1180))


if __name__ == "__main__":
    unittest.main()
