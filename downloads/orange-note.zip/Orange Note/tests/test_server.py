import http.client
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from orange_note import server as server_module
from orange_note.server import LocalServer


class LocalServerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        (root / "site").mkdir()
        (root / "site" / "index.html").write_text("<h1>ok</h1>", encoding="utf-8")
        (root / "secret.txt").write_text("segredo", encoding="utf-8")
        self.attachments = root / "attachments"
        patcher = patch.object(server_module, "ATTACHMENTS_DIR", self.attachments)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.server = LocalServer(root / "site")
        self.server.start()
        self.addCleanup(self.server.server_close)
        self.addCleanup(self.server.shutdown)

    def request(self, method, path, body=None, headers=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.server.port, timeout=5)
        connection.request(method, path, body=body, headers=headers or {})
        response = connection.getresponse()
        data = response.read()
        connection.close()
        return response, data

    def upload(self, name, content, token=None):
        return self.request(
            "POST",
            f"/api/upload?name={name}",
            body=content,
            headers={"X-Orange-Token": self.server.token if token is None else token},
        )

    def test_serves_frontend_and_blocks_path_traversal(self):
        response, data = self.request("GET", "/")
        self.assertEqual((response.status, data), (200, b"<h1>ok</h1>"))
        response, _ = self.request("GET", "/..%2Fsecret.txt")
        self.assertIn(response.status, {403, 404})
        response, _ = self.request("GET", "/%2e%2e/secret.txt")
        self.assertIn(response.status, {403, 404})

    def test_rejects_foreign_host_header(self):
        response, _ = self.request("GET", "/", headers={"Host": "evil.example"})
        self.assertEqual(response.status, 403)

    def test_upload_requires_token(self):
        response, _ = self.upload("a.png", b"x", token="errado")
        self.assertEqual(response.status, 403)
        self.assertFalse(self.attachments.exists())

    def test_upload_image_and_file_are_stored_and_served_safely(self):
        response, data = self.upload("foto.PNG", b"\x89PNG-data")
        info = json.loads(data)
        self.assertEqual((response.status, info["kind"], info["name"]), (200, "image", "foto.PNG"))
        response, body = self.request("GET", f"/attachments/{info['file']}")
        self.assertEqual((response.status, response.getheader("Content-Type")), (200, "image/png"))
        self.assertEqual(body, b"\x89PNG-data")

        response, data = self.upload("pagina.html", b"<script>alert(1)</script>")
        info = json.loads(data)
        self.assertEqual(info["kind"], "file")
        response, _ = self.request("GET", f"/attachments/{info['file']}")
        self.assertEqual(response.getheader("Content-Type"), "application/octet-stream")
        self.assertEqual(response.getheader("Content-Disposition"), "attachment")

    def test_attachment_names_must_match_generated_pattern(self):
        (self.attachments).mkdir()
        (self.attachments / "nota.txt").write_text("x", encoding="utf-8")
        response, _ = self.request("GET", "/attachments/nota.txt")
        self.assertEqual(response.status, 404)
        response, _ = self.request("GET", "/attachments/..%2Fsite%2Findex.html")
        self.assertEqual(response.status, 404)


if __name__ == "__main__":
    unittest.main()
