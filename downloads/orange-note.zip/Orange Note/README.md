# Orange Notes

App de notas nativo para Windows, com o design do projeto Figma (`Orange Note app design figma/`) e a logo `orange-note-logo.png`.

## Arquitetura

- **Janela nativa**: [pywebview](https://pywebview.flowrl.com) com WebView2 (já incluso no Windows 10/11). Sem Electron, sem Qt: o app ocupa ~25 MB e abre em ~2,5 s.
- **Interface**: React + Tailwind v4 em `frontend/` (mesmas fontes, cores e componentes do Figma), servida por um servidor local em `127.0.0.1` com porta aleatória.
- **Dados**: Python + SQLite em `%APPDATA%\Orange Note\` (`orange_note.db` e `attachments\`). O banco antigo em `data\orange_note.db` é migrado na primeira execução.

## Recursos

- Criar, editar, apagar (com **Desfazer**) e buscar notas; salvamento automático.
- **Arrastar e soltar** os cartões para reorganizar; a ordem é salva.
- **Leitura primeiro**: clicar no cartão abre só a nota. O editor fica oculto e aparece com **duplo clique** no texto ou no botão da **caneta** ao lado de "voltar". Nota nova já abre em edição.
- Editor rico fixo no rodapé (fundo opaco, não some ao rolar): negrito, itálico, sublinhado, tachado, título, citação, listas, link e cor da nota. Em janela estreita a barra **rola na horizontal arrastando** (sem quebra de linha).
- **Janela estilo post-it**: pode ser reduzida até 260 × 220 px. Abaixo de 400 px o layout fica compacto e os cartões empilham.
- **Imagens** (botão, colar com Ctrl+V ou arrastar para o editor) e **arquivos anexos** (abrem no app padrão do Windows; executáveis e scripts só são mostrados no Explorer).
- Atalhos: `Ctrl+N` nova nota; `Esc` sai da edição e, na leitura, volta à lista; `Ctrl+clique` abre um link durante a edição.

## Executar

Pré-requisitos: Python 3.11+ e, para recompilar a interface, Node.js 20+.

```powershell
python -m venv .venv
.\.venv\Scripts\pip install -r requirements.txt
cd frontend; npm install; npm run build; cd ..
.\.venv\Scripts\python.exe app.py
```

Ou use `launch_orange_note.bat`.

## Gerar o executável

```powershell
.\build_exe.bat
```

Resultado: `dist\Orange Notes\Orange Notes.exe` (copie a pasta inteira para distribuir).

## Testes

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests
```
