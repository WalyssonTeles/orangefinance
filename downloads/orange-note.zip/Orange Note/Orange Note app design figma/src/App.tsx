import { useEffect, useMemo, useState } from 'react'
import icon from './assets/orange-note-icon.png'
import Editor, { COLORS, type Note } from './Editor'

const KEY = 'orange-note:v1'

const SEED: Note[] = [
  {
    id: 's1',
    title: 'Bem-vindo ao Orange Note',
    html: '<p>Toque em qualquer cartão para abrir a nota completa e editar com <b>negrito</b>, <i>itálico</i>, listas e títulos.</p><ul><li>Crie notas com o botão laranja</li><li>Escolha uma cor para cada nota</li></ul>',
    color: 'butter',
    updated: Date.now(),
  },
  {
    id: 's2',
    title: 'Lista de compras',
    html: '<ul><li>Laranjas-pera (1 dúzia)</li><li>Café em grãos</li><li>Pão de fermentação natural</li><li>Manjericão</li></ul>',
    color: 'mint',
    updated: Date.now() - 3600_000,
  },
  {
    id: 's3',
    title: 'Ideias para o fim de semana',
    html: '<ol><li>Feira de domingo</li><li>Ler o capítulo 4</li><li>Ligar para a vovó</li></ol><blockquote>Fazer pouco, mas com atenção.</blockquote>',
    color: 'peach',
    updated: Date.now() - 86400_000,
  },
]

const plain = (html: string) =>
  new DOMParser().parseFromString(html.replace(/<\/(p|div|li|h2|blockquote)>/g, ' </$1>'), 'text/html').body
    .textContent?.trim() ?? ''

export default function App() {
  const [notes, setNotes] = useState<Note[]>(() => {
    try {
      const raw = localStorage.getItem(KEY)
      return raw ? JSON.parse(raw) : SEED
    } catch {
      return SEED
    }
  })
  const [openId, setOpenId] = useState<string | null>(null)
  const [query, setQuery] = useState('')
  const [undo, setUndo] = useState<{ note: Note; index: number } | null>(null)

  useEffect(() => localStorage.setItem(KEY, JSON.stringify(notes)), [notes])
  useEffect(() => {
    if (!undo) return
    const t = setTimeout(() => setUndo(null), 5000)
    return () => clearTimeout(t)
  }, [undo])

  const open = notes.find((n) => n.id === openId)

  const filtered = useMemo(() => {
    const q = query.toLowerCase()
    return notes
      .filter((n) => !q || n.title.toLowerCase().includes(q) || plain(n.html).toLowerCase().includes(q))
      .sort((a, b) => b.updated - a.updated)
  }, [notes, query])

  const create = () => {
    const n: Note = { id: crypto.randomUUID(), title: '', html: '', color: 'butter', updated: Date.now() }
    setNotes((p) => [n, ...p])
    setOpenId(n.id)
  }
  const patch = (id: string, p: Partial<Note>) =>
    setNotes((all) => all.map((n) => (n.id === id ? { ...n, ...p, updated: Date.now() } : n)))
  const remove = (id: string) => {
    const index = notes.findIndex((n) => n.id === id)
    setUndo({ note: notes[index], index })
    setNotes((p) => p.filter((n) => n.id !== id))
    setOpenId(null)
  }
  const back = () => {
    if (open && !open.title.trim() && !plain(open.html)) setNotes((p) => p.filter((n) => n.id !== open.id))
    setOpenId(null)
  }

  if (open) {
    return (
      <Editor
        note={open}
        onChange={(p) => patch(open.id, p)}
        onBack={back}
        onDelete={() => remove(open.id)}
      />
    )
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-20 border-b border-line bg-cream/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:gap-5 sm:px-8">
          <img src={icon} alt="" className="size-11 drop-shadow-md" />
          <h1 className="font-display text-2xl font-extrabold tracking-tight">
            Orange<span className="text-orange-deep">Note</span>
          </h1>
          <label className="ml-auto flex w-full max-w-xs items-center gap-2 rounded-full border border-line bg-white px-4 py-2 focus-within:ring-2 focus-within:ring-orange">
            <span aria-hidden className="text-ink-soft">⌕</span>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar notas"
              aria-label="Buscar notas"
              className="w-full bg-transparent text-sm outline-none placeholder:text-ink-soft/70"
            />
          </label>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-32 pt-10 sm:px-8">
        <div className="mb-8 flex items-end justify-between gap-4">
          <div>
            <p className="text-sm font-semibold uppercase tracking-widest text-leaf">Suas anotações</p>
            <h2 className="font-display text-4xl font-extrabold tracking-tight sm:text-6xl">
              {notes.length} {notes.length === 1 ? 'ideia' : 'ideias'}, <span className="text-orange-deep">espremidas.</span>
            </h2>
          </div>
          <button
            onClick={create}
            className="hidden shrink-0 items-center gap-2 rounded-full bg-orange px-6 py-3 font-bold text-ink shadow-[0_8px_0_-2px_var(--color-orange-deep)] transition hover:-translate-y-0.5 active:translate-y-1 active:shadow-none outline-none focus-visible:ring-2 focus-visible:ring-ink sm:flex"
          >
            <span className="text-xl leading-none">+</span> Nova nota
          </button>
        </div>

        {filtered.length === 0 ? (
          <div className="rise flex flex-col items-center gap-4 py-20 text-center">
            <img src={icon} alt="" className="size-32" />
            <p className="font-display text-2xl font-bold">
              {query ? 'Nada encontrado' : 'Nenhuma nota ainda'}
            </p>
            <p className="text-ink-soft">{query ? 'Tente outra palavra.' : 'Crie a primeira nota com o botão laranja.'}</p>
          </div>
        ) : (
          <ul className="columns-1 gap-5 sm:columns-2 lg:columns-3">
            {filtered.map((n, i) => (
              <li
                key={n.id}
                className="rise group relative mb-5 break-inside-avoid"
                style={{ animationDelay: `${Math.min(i, 8) * 40}ms` }}
              >
                <button
                  onClick={() => setOpenId(n.id)}
                  className="block w-full rounded-3xl p-6 text-left shadow-[0_10px_30px_-18px_rgba(120,60,10,0.6)] ring-1 ring-black/5 transition duration-200 hover:-translate-y-1 hover:rotate-[-0.6deg] hover:shadow-[0_22px_40px_-20px_rgba(120,60,10,0.6)] outline-none focus-visible:ring-2 focus-visible:ring-orange-deep"
                  style={{ background: COLORS[n.color] }}
                >
                  <h3 className="mb-2 pr-8 font-display text-xl font-bold leading-tight">
                    {n.title || 'Sem título'}
                  </h3>
                  <p className="line-clamp-6 text-[15px] leading-relaxed text-ink/80">
                    {plain(n.html) || 'Nota vazia'}
                  </p>
                  <p className="mt-4 text-xs font-medium uppercase tracking-widest text-ink-soft">
                    {new Date(n.updated).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}
                  </p>
                </button>
                <button
                  onClick={() => remove(n.id)}
                  aria-label={`Apagar ${n.title || 'nota'}`}
                  className="absolute right-3 top-3 grid size-8 place-items-center rounded-full bg-white/70 text-sm text-ink-soft opacity-100 transition hover:bg-orange-deep hover:text-white sm:opacity-0 sm:group-hover:opacity-100 focus-visible:opacity-100 outline-none focus-visible:ring-2 focus-visible:ring-orange-deep"
                >
                  ✕
                </button>
              </li>
            ))}
          </ul>
        )}
      </main>

      <button
        onClick={create}
        aria-label="Nova nota"
        className="fixed bottom-6 right-6 grid size-16 place-items-center rounded-full bg-orange text-4xl font-light text-ink shadow-[0_8px_0_-2px_var(--color-orange-deep)] transition active:translate-y-1 active:shadow-none outline-none focus-visible:ring-2 focus-visible:ring-ink sm:hidden"
      >
        +
      </button>

      {undo && (
        <div
          role="status"
          className="rise fixed bottom-6 left-1/2 z-30 flex -translate-x-1/2 items-center gap-4 rounded-full bg-ink px-5 py-3 text-sm text-cream shadow-xl"
        >
          Nota apagada
          <button
            onClick={() => {
              setNotes((p) => {
                const c = [...p]
                c.splice(undo.index, 0, undo.note)
                return c
              })
              setUndo(null)
            }}
            className="font-bold text-orange hover:underline"
          >
            Desfazer
          </button>
        </div>
      )}
    </div>
  )
}
