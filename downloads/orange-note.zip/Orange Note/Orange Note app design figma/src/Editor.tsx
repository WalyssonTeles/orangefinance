import { useEffect, useRef } from 'react'
import icon from './assets/orange-note-icon.png'

export type Note = {
  id: string
  title: string
  html: string
  color: string
  updated: number
}

export const COLORS: Record<string, string> = {
  butter: 'var(--note-butter)',
  peach: 'var(--note-peach)',
  mint: 'var(--note-mint)',
  blush: 'var(--note-blush)',
  cream: 'var(--note-cream)',
}

const TOOLS: { cmd: string; arg?: string; label: string; icon: string; cls?: string }[] = [
  { cmd: 'bold', label: 'Negrito', icon: 'B', cls: 'font-bold' },
  { cmd: 'italic', label: 'Itálico', icon: 'I', cls: 'italic' },
  { cmd: 'underline', label: 'Sublinhado', icon: 'U', cls: 'underline' },
  { cmd: 'strikeThrough', label: 'Tachado', icon: 'S', cls: 'line-through' },
  { cmd: 'formatBlock', arg: 'h2', label: 'Título', icon: 'H' },
  { cmd: 'formatBlock', arg: 'blockquote', label: 'Citação', icon: '“' },
  { cmd: 'insertUnorderedList', label: 'Lista', icon: '•' },
  { cmd: 'insertOrderedList', label: 'Lista numerada', icon: '1.' },
  { cmd: 'removeFormat', label: 'Limpar formatação', icon: 'Tx' },
]

export default function Editor({
  note,
  onChange,
  onBack,
  onDelete,
}: {
  note: Note
  onChange: (patch: Partial<Note>) => void
  onBack: () => void
  onDelete: () => void
}) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (ref.current) {
      ref.current.innerHTML = note.html
      if (!note.html) ref.current.focus()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [note.id])

  const run = (cmd: string, arg?: string) => {
    ref.current?.focus()
    document.execCommand('styleWithCSS', false, 'false')
    document.execCommand(cmd, false, arg)
    onChange({ html: ref.current?.innerHTML ?? '' })
  }

  return (
    <div
      className="rise min-h-screen px-3 py-3 sm:px-8 sm:py-6 transition-colors"
      style={{ background: COLORS[note.color] }}
    >
      <div className="mx-auto flex max-w-3xl flex-col gap-4">
        <header className="flex items-center justify-between gap-2">
          <button
            onClick={onBack}
            className="flex items-center gap-2 rounded-full bg-white/70 px-4 py-2 text-sm font-semibold hover:bg-white focus-visible:ring-2 focus-visible:ring-orange-deep outline-none transition"
          >
            <span aria-hidden>←</span> Todas as notas
          </button>
          <div className="flex items-center gap-3">
            <div className="flex gap-1.5" role="radiogroup" aria-label="Cor da nota">
              {Object.keys(COLORS).map((c) => (
                <button
                  key={c}
                  role="radio"
                  aria-checked={note.color === c}
                  aria-label={c}
                  onClick={() => onChange({ color: c })}
                  className={`size-6 rounded-full border-2 transition hover:scale-110 outline-none focus-visible:ring-2 focus-visible:ring-orange-deep ${
                    note.color === c ? 'border-ink' : 'border-ink/20'
                  }`}
                  style={{ background: COLORS[c] }}
                />
              ))}
            </div>
            <button
              onClick={onDelete}
              aria-label="Apagar nota"
              className="rounded-full bg-white/70 px-4 py-2 text-sm font-semibold text-orange-deep hover:bg-orange-deep hover:text-white transition outline-none focus-visible:ring-2 focus-visible:ring-orange-deep"
            >
              Apagar
            </button>
          </div>
        </header>

        <div
          className="sticky top-2 z-10 flex flex-wrap gap-1 rounded-2xl bg-ink p-1.5 shadow-lg"
          role="toolbar"
          aria-label="Formatação"
        >
          {TOOLS.map((t) => (
            <button
              key={t.label}
              title={t.label}
              aria-label={t.label}
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => run(t.cmd, t.arg)}
              className={`grid h-9 min-w-9 place-items-center rounded-xl px-2 text-sm text-cream hover:bg-orange hover:text-ink transition outline-none focus-visible:ring-2 focus-visible:ring-orange ${t.cls ?? ''}`}
            >
              {t.icon}
            </button>
          ))}
        </div>

        <article className="rounded-[2rem] bg-white/55 p-6 shadow-[0_20px_50px_-25px_rgba(120,60,10,0.45)] sm:p-10 min-h-[60vh]">
          <input
            value={note.title}
            onChange={(e) => onChange({ title: e.target.value })}
            placeholder="Título"
            className="w-full bg-transparent font-display text-4xl font-extrabold tracking-tight outline-none placeholder:text-ink/30 sm:text-5xl"
          />
          <p className="mt-2 mb-6 text-xs font-medium uppercase tracking-widest text-ink-soft">
            Editado{' '}
            {new Date(note.updated).toLocaleString('pt-BR', {
              day: '2-digit',
              month: 'short',
              hour: '2-digit',
              minute: '2-digit',
            })}
          </p>
          <div
            ref={ref}
            contentEditable
            suppressContentEditableWarning
            data-placeholder="Comece a escrever…"
            onInput={() => onChange({ html: ref.current?.innerHTML ?? '' })}
            onPaste={(e) => {
              e.preventDefault()
              document.execCommand('insertText', false, e.clipboardData.getData('text/plain'))
            }}
            className="rich min-h-[40vh] text-lg leading-relaxed"
          />
        </article>
        <img src={icon} alt="" className="mx-auto size-8 opacity-70" />
      </div>
    </div>
  )
}
