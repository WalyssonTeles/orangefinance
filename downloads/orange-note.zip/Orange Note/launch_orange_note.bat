@echo off
cd /d "%~dp0"
if exist "dist\Orange Notes\Orange Notes.exe" (
    start "" "dist\Orange Notes\Orange Notes.exe"
) else if exist ".venv\Scripts\pythonw.exe" (
    start "" ".venv\Scripts\pythonw.exe" "app.py"
) else (
    start "" pythonw "app.py"
)
