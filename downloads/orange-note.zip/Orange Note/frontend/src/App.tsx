import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import icon from './assets/orange-note-logo.png'
import { bridge, type Note } from './api'
import Editor, { COLORS } from './Editor'
import { firstImage, isEmpty, plain } from './html'

type Undo = { snapshot: unknown; note: Note; index: number }

export default function App() {
  const [notes, setNotes] = useState<Note[] | null>(null)
  const notesRef = useRef<Note[]>([])
  const [openId, setOpenId] = useState<number | null>(null)
  const [query, setQuery] = useState('')
  const [undo, setUndo] = useState<Undo | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [dragId, setDragId] = useState<number | null>(null)
  const [overId, setOverId] = useState<number | null>(null)

  const timers = useRef(new Map<number, number>())
  const queue = useRef<Promise<unknown>>(Promise.resolve())

  const commit = useCallback((next: Note[]) => {
    notesRef.current = next
    setNotes(next)
  }, [])

  const fail = useCallback((err: unknown) => {
    setError(err instanceof Error ? err.message : String(err))
  }, [])

  const load = useCallback(() => bridge.listNotes().then(commit).catch(fail), [commit, fail])

  useEffect(() => {
    load()
  }, [load])

  useEffect(() => {
    if (!undo && !error) return
    const t = setTimeout(() => (setUndo(null), setError(null)), error ? 6000 : 5000)
    return () => clearTimeout(t)
  }, [undo, error])

  // Salvamento automático com debounce; as gravações são enfileiradas para manter a ordem.
  const flush = useCallback(
    (id: number) => {
      const timer = timers.current.get(id)
      if (timer === undefined) return
      window.clearTimeout(timer)
      timers.current.delete(id)
      const note = notesRef.current.find((n) => n.id === id)
      if (note) queue.current = queue.current.then(() => bridge.saveNote(note)).catch(fail)
    },
    [fail],
  )
  const flushAll = useCallback(() => Array.from(timers.current.keys()).forEach(flush), [flush])

  useEffect(() => {
    const onHide = () => document.visibilityState === 'hidden' && flushAll()
    window.addEventListener('blur', flushAll)
    window.addEventListener('pagehide', flushAll)
    window.addEventListener('beforeunload', flushAll)
    document.addEventListener('visibilitychange', onHide)
    return () => {
      window.removeEventListener('blur', flushAll)
      window.removeEventListener('pagehide', flushAll)
      window.removeEventListener('beforeunload', flushAll)
      document.removeEventListener('visibilitychange', onHide)
    }
  }, [flushAll])

  const patch = useCallback(
    (id: number, p: Partial<Note>) => {
      commit(notesRef.current.map((n) => (n.id === id ? { ...n, ...p, updated: Date.now() } : n)))
      window.clearTimeout(timers.current.get(id))
      timers.current.set(id, window.setTimeout(() => flush(id), 250))
    },
    [commit, flush],
  )

  const open = notes?.find((n) => n.id === openId)

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    return (notes ?? []).filter((n) => !q || n.title.toLowerCase().includes(q) || plain(n.html).toLowerCase().includes(q))
  }, [notes, query])

  const create = useCallback(async () => {
    try {
      const n = await bridge.createNote()
      commit([n, ...notesRef.current])
      setOpenId(n.id)
    } catch (err) {
      fail(err)
    }
  }, [commit, fail])

  const remove = useCallback(
    async (id: number) => {
      const index = notesRef.current.findIndex((n) => n.id === id)
      const note = notesRef.current[index]
      if (!note) return
      window.clearTimeout(timers.current.get(id))
      timers.current.delete(id)
      await queue.current
      try {
        const snapshot = await bridge.deleteNote(id)
        commit(notesRef.current.filter((n) => n.id !== id))
        setOpenId(null)
        if (!isEmpty(note) && snapshot) setUndo({ snapshot, note, index })
      } catch (err) {
        fail(err)
      }
    },
    [commit, fail],
  )

  const restore = async () => {
    if (!undo) return
    try {
      const note = await bridge.restoreNote(undo.snapshot)
      const next = [...notesRef.current]
      next.splice(Math.min(undo.index, next.length), 0, note)
      commit(next)
      setUndo(null)
    } catch (err) {
      fail(err)
    }
  }

  const back = useCallback(() => {
    if (open && isEmpty(open)) remove(open.id)
    else {
      if (open) flush(open.id)
      setOpenId(null)
    }
  }, [open, remove, flush])

  const move = async (sourceId: number, targetId: number) => {
    const list = [...notesRef.current]
    const from = list.findIndex((n) => n.id === sourceId)
    const to = list.findIndex((n) => n.id === targetId)
    if (from < 0 || to < 0 || from === to) return
    const [item] = list.splice(from, 1)
    list.splice(to, 0, item)
    commit(list)
    try {
      await bridge.reorderNotes(list.map((n) => n.id))
    } catch (err) {
      fail(err)
      load()
    }
  }

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'n' && openId === null) {
        e.preventDefault()
        create()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [create, openId])

  const toast = (children: React.ReactNode) => (
    <div
      role="status"
      className={`rise fixed left-1/2 z-30 flex max-w-[92vw] -translate-x-1/2 items-center gap-4 rounded-full bg-ink px-5 py-3 text-sm text-cream shadow-xl ${
        open ? 'bottom-28' : 'bottom-6'
      }`}
    >
      {children}
    </div>
  )

  const overlay = (
    <>
      {undo &&
        toast(
          <>
            Nota apagada
            <button onClick={restore} className="font-bold text-orange hover:underline">
              Desfazer
            </button>
          </>,
        )}
      {error && !undo && toast(<span>{error}</span>)}
    </>
  )

  if (notes === null) return <div className="min-h-screen" />

  if (open) {
    return (
      <>
        <Editor
          key={open.id}
          note={open}
          onChange={(p) => patch(open.id, p)}
          onBack={back}
          onDelete={() => remove(open.id)}
          onError={(m) => setError(m)}
        />
        {overlay}
      </>
    )
  }

  const canDrag = !query.trim()

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-20 border-b border-line bg-cream/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:gap-5 sm:px-8 max-[400px]:gap-2 max-[400px]:px-2.5 max-[400px]:py-2">
          <img src={icon} alt="" className="size-11 shrink-0 drop-shadow-md max-[400px]:size-9" />
          <h1 className="font-display text-2xl font-extrabold tracking-tight max-[400px]:hidden">
            Orange<span className="text-orange-deep">Note</span>
          </h1>
          <label className="ml-auto flex w-full min-w-0 max-w-xs items-center gap-2 rounded-full border border-line bg-white px-4 py-2 focus-within:ring-2 focus-within:ring-orange max-[400px]:px-3 max-[400px]:py-1.5">
            <span aria-hidden className="text-ink-soft">⌕</span>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar notas"
              aria-label="Buscar notas"
              className="w-full bg-transparent text-sm outline-none placeholder:text-ink-soft/70"
            />
          </label>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-32 pt-10 sm:px-8 max-[400px]:px-2.5 max-[400px]:pt-5">
        <div className="mb-8 flex items-end justify-between gap-4 max-[400px]:mb-5">
          <div>
            <p className="text-sm font-semibold uppercase tracking-widest text-leaf max-[400px]:text-xs">Suas anotações</p>
            <h2 className="font-display text-4xl font-extrabold tracking-tight sm:text-6xl max-[400px]:text-3xl">

              {notes.length} {notes.length === 1 ? 'ideia' : 'ideias'}, <span className="text-orange-deep">espremidas.</span>
            </h2>
            {notes.length > 1 && canDrag && (
              <p className="mt-3 text-sm text-ink-soft">Arraste os cartões para organizar do seu jeito.</p>
            )}
          </div>
          <button
            onClick={create}
            className="hidden shrink-0 items-center gap-2 rounded-full bg-orange px-6 py-3 font-bold text-ink shadow-[0_8px_0_-2px_var(--color-orange-deep)] transition hover:-translate-y-0.5 active:translate-y-1 active:shadow-none outline-none focus-visible:ring-2 focus-visible:ring-ink sm:flex"
          >
            <span className="text-xl leading-none">+</span> Nova nota
          </button>
        </div>

        {filtered.length === 0 ? (
          <div className="rise flex flex-col items-center gap-4 py-20 text-center">
            <img src={icon} alt="" className="size-32" />
            <p className="font-display text-2xl font-bold">{query ? 'Nada encontrado' : 'Nenhuma nota ainda'}</p>
            <p className="text-ink-soft">{query ? 'Tente outra palavra.' : 'Crie a primeira nota com o botão laranja.'}</p>
          </div>
        ) : (
          <ul className="columns-1 gap-5 sm:columns-2 lg:columns-3">
            {filtered.map((n, i) => {
              const image = firstImage(n.html)
              const text = plain(n.html)
              return (
                <li
                  key={n.id}
                  draggable={canDrag}
                  onDragStart={(e) => {
                    e.dataTransfer.effectAllowed = 'move'
                    e.dataTransfer.setData('text/plain', String(n.id))
                    setDragId(n.id)
                  }}
                  onDragEnter={() => dragId !== null && setOverId(n.id)}
                  onDragOver={(e) => {
                    if (dragId === null) return
                    e.preventDefault()
                    e.dataTransfer.dropEffect = 'move'
                  }}
                  onDrop={(e) => {
                    e.preventDefault()
                    if (dragId !== null) move(dragId, n.id)
                    setDragId(null)
                    setOverId(null)
                  }}
                  onDragEnd={() => (setDragId(null), setOverId(null))}
                  className={`rise group relative mb-5 break-inside-avoid transition duration-150 ${
                    dragId === n.id ? 'scale-[0.97] opacity-40' : ''
                  } ${overId === n.id && dragId !== n.id ? 'rounded-3xl ring-4 ring-orange ring-offset-4 ring-offset-cream' : ''}`}
                  style={{ animationDelay: `${Math.min(i, 8) * 40}ms` }}
                >
                  <div
                    role="button"
                    tabIndex={0}
                    onClick={() => setOpenId(n.id)}
                    onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), setOpenId(n.id))}
                    className={`block w-full rounded-3xl p-6 text-left max-[400px]:p-4 shadow-[0_10px_30px_-18px_rgba(120,60,10,0.6)] ring-1 ring-black/5 transition duration-200 hover:-translate-y-1 hover:rotate-[-0.6deg] hover:shadow-[0_22px_40px_-20px_rgba(120,60,10,0.6)] outline-none focus-visible:ring-2 focus-visible:ring-orange-deep ${
                      canDrag ? 'cursor-grab active:cursor-grabbing' : 'cursor-pointer'
                    }`}
                    style={{ background: COLORS[n.color] ?? COLORS.butter }}
                  >
                    {image && (
                      <img src={image} alt="" draggable={false} className="mb-4 max-h-44 w-full rounded-2xl object-cover" />
                    )}
                    <h3 className="mb-2 truncate pr-8 font-display text-xl font-bold leading-tight">{n.title || 'Sem título'}</h3>
                    <p className="line-clamp-3 text-[15px] leading-relaxed text-ink/80">
                      {text || (image ? 'Imagem' : 'Nota vazia')}
                    </p>
                    <p className="mt-4 text-xs font-medium uppercase tracking-widest text-ink-soft">
                      {new Date(n.updated).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}
                    </p>
                  </div>
                  <button
                    onClick={() => remove(n.id)}
                    aria-label={`Apagar ${n.title || 'nota'}`}
                    className="absolute right-3 top-3 grid size-8 place-items-center rounded-full bg-white/70 text-sm text-ink-soft opacity-100 transition hover:bg-orange-deep hover:text-white sm:opacity-0 sm:group-hover:opacity-100 focus-visible:opacity-100 outline-none focus-visible:ring-2 focus-visible:ring-orange-deep"
                  >
                    ✕
                  </button>
                </li>
              )
            })}
          </ul>
        )}
      </main>

      <button
        onClick={create}
        aria-label="Nova nota"
        className="fixed bottom-6 right-6 grid size-16 place-items-center rounded-full bg-orange text-4xl font-light text-ink shadow-[0_8px_0_-2px_var(--color-orange-deep)] transition active:translate-y-1 active:shadow-none outline-none focus-visible:ring-2 focus-visible:ring-ink sm:hidden"
      >
        +
      </button>

      {overlay}
    </div>
  )
}
