import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react'
import icon from './assets/orange-note-logo.png'
import { bridge, type Note } from './api'
import { esc, fmtSize, isEmpty, sanitize } from './html'

export const COLORS: Record<string, string> = {
  butter: 'var(--note-butter)',
  peach: 'var(--note-peach)',
  mint: 'var(--note-mint)',
  blush: 'var(--note-blush)',
  cream: 'var(--note-cream)',
}

const Svg = ({ children }: { children: ReactNode }) => (
  <svg viewBox="0 0 24 24" className="size-[18px]" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    {children}
  </svg>
)
const LinkIcon = () => (
  <Svg>
    <path d="M10 13a5 5 0 0 0 7.1 0l3-3a5 5 0 0 0-7.1-7.1l-1.7 1.7" />
    <path d="M14 11a5 5 0 0 0-7.1 0l-3 3a5 5 0 0 0 7.1 7.1l1.7-1.7" />
  </Svg>
)
const ImageIcon = () => (
  <Svg>
    <rect x="3" y="3" width="18" height="18" rx="3" />
    <circle cx="9" cy="9" r="1.6" />
    <path d="m21 15-4.5-4.5L6 21" />
  </Svg>
)
const ClipIcon = () => (
  <Svg>
    <path d="m21 11.5-8.6 8.6a5.5 5.5 0 0 1-7.8-7.8l8.9-8.9a3.7 3.7 0 0 1 5.2 5.2l-8.9 8.9a1.8 1.8 0 0 1-2.6-2.6l8.2-8.1" />
  </Svg>
)
const PenIcon = () => (
  <Svg>
    <path d="M12 20h9" />
    <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z" />
  </Svg>
)
const TrashIcon = () => (
  <Svg>
    <path d="M3 6h18" />
    <path d="M8 6V4h8v2" />
    <path d="m6 6 1 14h10l1-14" />
  </Svg>
)

type Tool = { cmd: string; arg?: string; label: string; icon: ReactNode; cls?: string; state?: string }

const TOOLS: Tool[][] = [
  [
    { cmd: 'bold', label: 'Negrito (Ctrl+B)', icon: 'B', cls: 'font-bold', state: 'bold' },
    { cmd: 'italic', label: 'Itálico (Ctrl+I)', icon: 'I', cls: 'italic', state: 'italic' },
    { cmd: 'underline', label: 'Sublinhado (Ctrl+U)', icon: 'U', cls: 'underline', state: 'underline' },
    { cmd: 'strikeThrough', label: 'Tachado', icon: 'S', cls: 'line-through', state: 'strikeThrough' },
  ],
  [
    { cmd: 'formatBlock', arg: 'h2', label: 'Título', icon: 'H', state: 'h2' },
    { cmd: 'formatBlock', arg: 'blockquote', label: 'Citação', icon: '“', state: 'blockquote' },
    { cmd: 'insertUnorderedList', label: 'Lista', icon: '•', state: 'insertUnorderedList' },
    { cmd: 'insertOrderedList', label: 'Lista numerada', icon: '1.', state: 'insertOrderedList' },
    { cmd: 'removeFormat', label: 'Limpar formatação', icon: 'Tx' },
  ],
]

const SIMPLE_STATES = ['bold', 'italic', 'underline', 'strikeThrough', 'insertUnorderedList', 'insertOrderedList']

// Rolagem horizontal por arraste (sem barra, sem quebra de linha), como num carrossel.
function DragScroll({ children, className = '', ...rest }: React.HTMLAttributes<HTMLDivElement>) {
  const el = useRef<HTMLDivElement>(null)
  const drag = useRef<{ x: number; left: number; id: number; moved: boolean } | null>(null)
  const suppressClick = useRef(false)

  useEffect(() => {
    const node = el.current
    if (!node) return
    const onWheel = (e: WheelEvent) => {
      if (node.scrollWidth <= node.clientWidth || Math.abs(e.deltaY) < Math.abs(e.deltaX)) return
      e.preventDefault()
      node.scrollLeft += e.deltaY
    }
    node.addEventListener('wheel', onWheel, { passive: false })
    return () => node.removeEventListener('wheel', onWheel)
  }, [])

  const end = () => {
    if (drag.current?.moved) {
      suppressClick.current = true
      window.setTimeout(() => (suppressClick.current = false), 60)
    }
    drag.current = null
  }

  return (
    <div
      {...rest}
      ref={el}
      className={`no-scrollbar overflow-x-auto overscroll-x-contain select-none touch-pan-x ${className}`}
      onPointerDown={(e) => {
        if (e.pointerType !== 'mouse' || e.button !== 0 || !el.current) return
        drag.current = { x: e.clientX, left: el.current.scrollLeft, id: e.pointerId, moved: false }
      }}
      onPointerMove={(e) => {
        const d = drag.current
        if (!d || !el.current) return
        const dx = e.clientX - d.x
        if (!d.moved && Math.abs(dx) > 5) {
          d.moved = true
          el.current.setPointerCapture(d.id)
        }
        if (d.moved) el.current.scrollLeft = d.left - dx
      }}
      onPointerUp={end}
      onPointerCancel={end}
      onClickCapture={(e) => {
        if (suppressClick.current) {
          e.preventDefault()
          e.stopPropagation()
        }
      }}
    >
      {children}
    </div>
  )
}

export default function Editor({
  note,
  onChange,
  onBack,
  onDelete,
  onError,
}: {
  note: Note
  onChange: (patch: Partial<Note>) => void
  onBack: () => void
  onDelete: () => void
  onError: (message: string) => void
}) {
  const ref = useRef<HTMLDivElement>(null)
  const titleRef = useRef<HTMLInputElement>(null)
  const imageInput = useRef<HTMLInputElement>(null)
  const fileInput = useRef<HTMLInputElement>(null)
  const range = useRef<Range | null>(null)
  const [editing, setEditing] = useState(() => isEmpty(note))
  const wasEditing = useRef(editing)
  const pendingPoint = useRef<{ x: number; y: number; title: boolean } | null>(null)
  const [active, setActive] = useState<Set<string>>(new Set())
  const [link, setLink] = useState<string | null>(null)
  const [busy, setBusy] = useState(0)
  const [dropping, setDropping] = useState(false)

  useEffect(() => {
    if (ref.current) ref.current.innerHTML = sanitize(note.html)
    if (editing && !note.title) titleRef.current?.focus()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [note.id])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape' || link !== null) return
      if (editing && !isEmpty(note)) setEditing(false)
      else onBack()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onBack, link, editing, note])

  useEffect(() => {
    if (!editing) return
    const onSelection = () => {
      const sel = window.getSelection()
      if (!sel || !sel.rangeCount || !ref.current?.contains(sel.anchorNode)) return
      range.current = sel.getRangeAt(0).cloneRange()
      const next = new Set(SIMPLE_STATES.filter((c) => document.queryCommandState(c)))
      // Links são sublinhados pelo estilo, o que não significa que o texto esteja com "U" aplicado.
      if (next.has('underline') && sel.anchorNode?.parentElement?.closest('a')) next.delete('underline')
      const block = document.queryCommandValue('formatBlock').toLowerCase()
      if (block === 'h2' || block === 'blockquote') next.add(block)
      setActive(next)
    }
    document.addEventListener('selectionchange', onSelection)
    return () => document.removeEventListener('selectionchange', onSelection)
  }, [editing])

  const restore = useCallback(() => {
    const el = ref.current
    if (!el) return
    el.focus()
    const sel = window.getSelection()
    if (!sel) return
    if (!range.current || !el.contains(range.current.startContainer)) {
      range.current = document.createRange()
      range.current.selectNodeContents(el)
      range.current.collapse(false)
    }
    sel.removeAllRanges()
    sel.addRange(range.current)
  }, [])

  // Ao entrar no modo edição (duplo clique ou botão da caneta), o cursor vai para onde se clicou.
  useEffect(() => {
    if (wasEditing.current === editing) return
    wasEditing.current = editing
    if (!editing) {
      setLink(null)
      window.getSelection()?.removeAllRanges()
      return
    }
    const point = pendingPoint.current
    pendingPoint.current = null
    requestAnimationFrame(() => {
      if (point?.title) return titleRef.current?.focus()
      const hit = point ? document.caretRangeFromPoint?.(point.x, point.y) : null
      range.current = hit && ref.current?.contains(hit.startContainer) ? hit : null
      restore()
    })
  }, [editing, restore])

  const emit = useCallback(() => onChange({ html: ref.current?.innerHTML ?? '' }), [onChange])

  const run = (cmd: string, arg?: string) => {
    restore()
    document.execCommand('styleWithCSS', false, 'false')
    if (cmd === 'formatBlock' && document.queryCommandValue('formatBlock').toLowerCase() === arg) arg = 'p'
    document.execCommand(cmd, false, arg)
    emit()
  }

  const insertHtml = (html: string) => {
    restore()
    document.execCommand('insertHTML', false, html)
    emit()
  }

  const attach = async (files: File[]) => {
    for (const file of files) {
      setBusy((n) => n + 1)
      try {
        const up = await bridge.upload(file)
        insertHtml(
          up.kind === 'image'
            ? `<p><img src="/attachments/${up.file}" alt="${esc(up.name)}"></p>`
            : `<a class="file-chip" href="#" data-file="${up.file}" contenteditable="false">${esc(up.name)} · ${fmtSize(up.size)}</a>&nbsp;`,
        )
      } catch (err) {
        onError(err instanceof Error ? err.message : String(err))
      } finally {
        setBusy((n) => n - 1)
      }
    }
  }

  const pick = (input: HTMLInputElement | null) => {
    if (!input) return
    input.value = ''
    input.click()
  }

  const applyLink = () => {
    const raw = (link ?? '').trim()
    setLink(null)
    if (!raw) return restore()
    const url = /^(https?:|mailto:)/i.test(raw) ? raw : `https://${raw}`
    try {
      if (!/^(https?|mailto):$/.test(new URL(url).protocol)) throw new Error()
    } catch {
      onError('Endereço de link inválido.')
      return restore()
    }
    restore()
    const sel = window.getSelection()
    if (sel && !sel.isCollapsed) document.execCommand('createLink', false, url)
    else document.execCommand('insertHTML', false, `<a href="${esc(url)}">${esc(raw)}</a>`)
    ref.current?.querySelectorAll('a[href]:not([title])').forEach((a) => a.setAttribute('title', 'Ctrl+clique para abrir'))
    emit()
  }

  const onEditorClick = (e: React.MouseEvent) => {
    const a = (e.target as HTMLElement).closest('a')
    if (!a) return
    const file = a.getAttribute('data-file')
    if (file) {
      e.preventDefault()
      bridge.openAttachment(file).then((ok) => !ok && onError('O anexo não foi encontrado.'))
    } else if (a.href) {
      e.preventDefault()
      if (!editing || e.ctrlKey || e.metaKey) bridge.openUrl(a.href)
    }
  }

  const onNoteDoubleClick = (e: React.MouseEvent) => {
    if (editing || (e.target as HTMLElement).closest('a')) return
    pendingPoint.current = { x: e.clientX, y: e.clientY, title: !!(e.target as HTMLElement).closest('input') }
    setEditing(true)
  }

  const onDrop = (e: React.DragEvent) => {
    setDropping(false)
    if (!editing || !e.dataTransfer.files.length) return
    e.preventDefault()
    const pos = document.caretRangeFromPoint?.(e.clientX, e.clientY)
    if (pos && ref.current?.contains(pos.startContainer)) range.current = pos
    attach(Array.from(e.dataTransfer.files))
  }

  const btn =
    'grid h-9 min-w-9 shrink-0 place-items-center rounded-xl px-2 text-sm transition outline-none focus-visible:ring-2 focus-visible:ring-orange'
  const sep = <span className="mx-1 h-5 w-px shrink-0 bg-cream/20" />

  return (
    <>
    <div
      className="rise min-h-screen transition-colors"
      style={{ background: COLORS[note.color] }}
    >
      <div
        className="sticky top-0 z-20 px-3 py-2 backdrop-blur sm:px-8 sm:py-3 max-[400px]:px-2 max-[400px]:py-1.5"
        style={{ background: `color-mix(in srgb, ${COLORS[note.color]} 90%, transparent)` }}
      >
        <header className="mx-auto flex max-w-3xl flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              aria-label="Todas as notas"
              className="flex h-9 items-center gap-2 rounded-full bg-white/70 px-4 text-sm font-semibold hover:bg-white focus-visible:ring-2 focus-visible:ring-orange-deep outline-none transition max-[400px]:px-3"
            >
              <span aria-hidden>←</span>
              <span className="max-[400px]:hidden">Todas as notas</span>
            </button>
            <button
              onClick={() => setEditing((v) => !v)}
              aria-label={editing ? 'Concluir edição' : 'Editar nota'}
              aria-pressed={editing}
              title={editing ? 'Concluir edição (Esc)' : 'Editar nota (ou duplo clique no texto)'}
              className={`grid size-9 place-items-center rounded-full transition outline-none focus-visible:ring-2 focus-visible:ring-orange-deep ${
                editing ? 'bg-ink text-cream' : 'bg-white/70 hover:bg-white'
              }`}
            >
              <PenIcon />
            </button>
          </div>
          <div className="flex items-center gap-3 max-[400px]:gap-2">
            <div className="flex gap-1.5 max-[400px]:gap-1" role="radiogroup" aria-label="Cor da nota">
              {Object.keys(COLORS).map((c) => (
                <button
                  key={c}
                  role="radio"
                  aria-checked={note.color === c}
                  aria-label={c}
                  onClick={() => onChange({ color: c })}
                  className={`size-6 rounded-full border-2 transition hover:scale-110 outline-none focus-visible:ring-2 focus-visible:ring-orange-deep max-[400px]:size-5 ${
                    note.color === c ? 'border-ink' : 'border-ink/20'
                  }`}
                  style={{ background: COLORS[c] }}
                />
              ))}
            </div>
            <button
              onClick={onDelete}
              aria-label="Apagar nota"
              title="Apagar nota"
              className="grid h-9 place-items-center rounded-full bg-white/70 px-4 text-sm font-semibold text-orange-deep hover:bg-orange-deep hover:text-white transition outline-none focus-visible:ring-2 focus-visible:ring-orange-deep max-[400px]:size-9 max-[400px]:px-0"
            >
              <span className="max-[400px]:hidden">Apagar</span>
              <span className="hidden max-[400px]:block">
                <TrashIcon />
              </span>
            </button>
          </div>
        </header>
      </div>

      <div className="mx-auto flex max-w-3xl flex-col gap-4 px-3 pb-3 pt-2 sm:px-8 sm:pb-6 max-[400px]:gap-3 max-[400px]:px-2 max-[400px]:pb-2">
        <article
          className={`rounded-[2rem] bg-white/55 p-6 shadow-[0_20px_50px_-25px_rgba(120,60,10,0.45)] sm:p-10 min-h-[60vh] transition max-[400px]:rounded-3xl max-[400px]:p-4 ${
            dropping ? 'ring-4 ring-orange' : ''
          }`}
          onDoubleClick={onNoteDoubleClick}
          onDragOver={(e) => {
            if (editing && e.dataTransfer.types.includes('Files')) {
              e.preventDefault()
              setDropping(true)
            }
          }}
          onDragLeave={() => setDropping(false)}
          onDrop={onDrop}
        >
          <input
            ref={titleRef}
            value={note.title}
            readOnly={!editing}
            onChange={(e) => onChange({ title: e.target.value })}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault()
                ref.current?.focus()
              }
            }}
            placeholder="Título"
            className={`w-full bg-transparent font-display text-4xl font-extrabold tracking-tight outline-none placeholder:text-ink/30 sm:text-5xl max-[400px]:text-3xl ${
              editing ? '' : 'cursor-default'
            }`}
          />
          <p className="mt-2 mb-6 text-xs font-medium uppercase tracking-widest text-ink-soft max-[400px]:mb-4">
            Editado{' '}
            {new Date(note.updated).toLocaleString('pt-BR', {
              day: '2-digit',
              month: 'short',
              hour: '2-digit',
              minute: '2-digit',
            })}
          </p>
          <div
            ref={ref}
            contentEditable={editing}
            suppressContentEditableWarning
            spellCheck={editing}
            data-placeholder={editing ? 'Comece a escrever…' : ''}
            onInput={emit}
            onClick={onEditorClick}
            onPaste={(e) => {
              e.preventDefault()
              if (e.clipboardData.files.length) attach(Array.from(e.clipboardData.files))
              else document.execCommand('insertText', false, e.clipboardData.getData('text/plain'))
            }}
            className={`rich min-h-[40vh] text-lg leading-relaxed max-[400px]:text-base ${editing ? '' : 'cursor-default'}`}
          />
        </article>
        <img src={icon} alt="" className="mx-auto size-8 opacity-70" />
        {editing && <div aria-hidden className={link !== null ? 'h-36' : 'h-20'} />}
      </div>
    </div>

      {/* Fora do contêiner animado: a animação "rise" criaria um bloco de contenção e quebraria o position: fixed. */}
      {editing && (
        <div className="fixed inset-x-0 bottom-0 z-20 px-3 pb-3 pt-2.5 max-[400px]:px-2 max-[400px]:pb-2">
          <div className="mx-auto flex max-w-3xl flex-col gap-2">
            {link !== null && (
              <form
                className="rise flex items-center gap-2 rounded-2xl bg-white p-2 shadow-md ring-1 ring-line"
                onSubmit={(e) => {
                  e.preventDefault()
                  applyLink()
                }}
              >
                <input
                  autoFocus
                  value={link}
                  onChange={(e) => setLink(e.target.value)}
                  onKeyDown={(e) => e.key === 'Escape' && (e.stopPropagation(), setLink(null), restore())}
                  placeholder="Cole o endereço do link (https://…)"
                  aria-label="Endereço do link"
                  className="w-full min-w-0 rounded-xl bg-transparent px-3 py-2 text-sm outline-none placeholder:text-ink/40"
                />
                <button type="submit" className="shrink-0 rounded-xl bg-orange px-4 py-2 text-sm font-bold text-ink hover:bg-orange-deep hover:text-white transition">
                  Aplicar
                </button>
                <button
                  type="button"
                  onClick={() => (setLink(null), restore())}
                  className="shrink-0 rounded-xl px-3 py-2 text-sm font-semibold text-ink-soft hover:bg-cream transition max-[400px]:hidden"
                >
                  Cancelar
                </button>
              </form>
            )}
            <DragScroll className="rounded-2xl bg-ink p-1.5" role="toolbar" aria-label="Formatação">
              <div className="mx-auto flex w-max items-center gap-1">
                {TOOLS.map((group, gi) => (
                  <div key={gi} className="flex items-center gap-1">
                    {gi > 0 && sep}
                    {group.map((t) => (
                      <button
                        key={t.label}
                        title={t.label}
                        aria-label={t.label}
                        aria-pressed={t.state ? active.has(t.state) : undefined}
                        onMouseDown={(e) => e.preventDefault()}
                        onClick={() => run(t.cmd, t.arg)}
                        className={`${btn} ${t.cls ?? ''} ${
                          t.state && active.has(t.state) ? 'bg-orange text-ink' : 'text-cream hover:bg-orange hover:text-ink'
                        }`}
                      >
                        {t.icon}
                      </button>
                    ))}
                  </div>
                ))}
                {sep}
                <button
                  title="Inserir link"
                  aria-label="Inserir link"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => setLink('')}
                  className={`${btn} text-cream hover:bg-orange hover:text-ink`}
                >
                  <LinkIcon />
                </button>
                <button
                  title="Inserir imagem"
                  aria-label="Inserir imagem"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => pick(imageInput.current)}
                  className={`${btn} text-cream hover:bg-orange hover:text-ink`}
                >
                  <ImageIcon />
                </button>
                <button
                  title="Anexar arquivo"
                  aria-label="Anexar arquivo"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => pick(fileInput.current)}
                  className={`${btn} text-cream hover:bg-orange hover:text-ink`}
                >
                  <ClipIcon />
                </button>
                {busy > 0 && <span className="shrink-0 px-3 text-xs font-semibold text-orange">Enviando…</span>}
              </div>
              <input
                ref={imageInput}
                type="file"
                accept="image/png,image/jpeg,image/gif,image/webp,image/bmp"
                multiple
                hidden
                onChange={(e) => attach(Array.from(e.target.files ?? []))}
              />
              <input ref={fileInput} type="file" multiple hidden onChange={(e) => attach(Array.from(e.target.files ?? []))} />
            </DragScroll>
          </div>
        </div>
      )}
    </>
  )
}
