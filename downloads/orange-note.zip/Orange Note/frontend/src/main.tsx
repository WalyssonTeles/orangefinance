import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'

// Soltar um arquivo fora do editor não deve navegar a janela para ele.
for (const type of ['dragover', 'drop']) {
  window.addEventListener(type, (e) => {
    if ((e as DragEvent).dataTransfer?.types.includes('Files')) e.preventDefault()
  })
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
