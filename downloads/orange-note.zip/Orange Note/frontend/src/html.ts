const BLOCKED = 'script,style,iframe,object,embed,link,meta,form,input,button,textarea,select,svg,math,base,audio,video'
const SAFE_HREF = /^(https?:|mailto:|#)/i
const SAFE_SRC = /^\/attachments\/[0-9a-f]{32}(\.[a-z0-9]{1,10})?$/i
const ALLOWED_ATTRS = new Set(['href', 'src', 'alt', 'title', 'class', 'data-file', 'contenteditable'])

// O HTML vem do banco local, mas é tratado como não confiável: o editor roda com acesso à ponte Python.
export function sanitize(html: string): string {
  const doc = new DOMParser().parseFromString(html, 'text/html')
  doc.body.querySelectorAll(BLOCKED).forEach((el) => el.remove())
  doc.body.querySelectorAll('*').forEach((el) => {
    for (const attr of Array.from(el.attributes)) {
      const name = attr.name.toLowerCase()
      const value = attr.value.trim()
      const ok =
        ALLOWED_ATTRS.has(name) &&
        (name !== 'href' || SAFE_HREF.test(value)) &&
        (name !== 'src' || SAFE_SRC.test(value)) &&
        (name !== 'class' || /^[\w -]+$/.test(value))
      if (!ok) el.removeAttribute(attr.name)
    }
    if (el.tagName === 'IMG' && !el.hasAttribute('src')) el.remove()
  })
  return doc.body.innerHTML
}

export const plain = (html: string) =>
  new DOMParser()
    .parseFromString(html.replace(/<\/(p|div|li|h2|blockquote|a)>/g, ' </$1>'), 'text/html')
    .body.textContent?.replace(/\s+/g, ' ')
    .trim() ?? ''

export const firstImage = (html: string) => {
  const m = /<img\b[^>]*\bsrc="(\/attachments\/[0-9a-f]{32}(?:\.[a-z0-9]{1,10})?)"/i.exec(html)
  return m ? m[1] : null
}

export const isEmpty = (n: { title: string; html: string }) =>
  !n.title.trim() && !plain(n.html) && !/<img\b|data-file=/i.test(n.html)

export const esc = (s: string) =>
  s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!)

export const fmtSize = (bytes: number) =>
  bytes < 1024
    ? `${bytes} B`
    : bytes < 1024 * 1024
      ? `${(bytes / 1024).toFixed(0)} KB`
      : `${(bytes / 1024 / 1024).toFixed(1)} MB`
