export type Note = {
  id: number
  title: string
  html: string
  color: string
  updated: number
}

export type Upload = { file: string; name: string; size: number; kind: 'image' | 'file' }

type PyApi = {
  get_token(): Promise<string>
  list_notes(): Promise<Note[]>
  create_note(color?: string): Promise<Note>
  save_note(id: number, title: string, html: string, color: string): Promise<number>
  delete_note(id: number): Promise<unknown>
  restore_note(snapshot: unknown): Promise<Note>
  reorder_notes(ids: number[]): Promise<boolean>
  open_attachment(name: string): Promise<boolean>
  open_url(url: string): Promise<boolean>
}

declare global {
  interface Window {
    pywebview?: { api: PyApi }
  }
}

const ready = new Promise<PyApi>((resolve) => {
  if (window.pywebview?.api) resolve(window.pywebview.api)
  else window.addEventListener('pywebviewready', () => resolve(window.pywebview!.api), { once: true })
})

let token: Promise<string> | null = null

export const bridge = {
  listNotes: async () => (await ready).list_notes(),
  createNote: async (color?: string) => (await ready).create_note(color),
  saveNote: async (n: Note) => (await ready).save_note(n.id, n.title, n.html, n.color),
  deleteNote: async (id: number) => (await ready).delete_note(id),
  restoreNote: async (snapshot: unknown) => (await ready).restore_note(snapshot),
  reorderNotes: async (ids: number[]) => (await ready).reorder_notes(ids),
  openAttachment: async (name: string) => (await ready).open_attachment(name),
  openUrl: async (url: string) => (await ready).open_url(url),
  upload: async (file: File): Promise<Upload> => {
    token ??= ready.then((api) => api.get_token())
    const res = await fetch(`/api/upload?name=${encodeURIComponent(file.name || 'arquivo')}`, {
      method: 'POST',
      headers: { 'X-Orange-Token': await token },
      body: file,
    })
    const data = await res.json()
    if (!res.ok) throw new Error(data.error ?? 'Falha ao enviar o arquivo')
    return data
  },
}
