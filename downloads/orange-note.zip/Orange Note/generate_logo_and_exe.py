import os
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw

base_dir = Path(__file__).resolve().parent

# Generate icon from reference-inspired design
W = H = 256
img = Image.new('RGBA', (W, H), (0, 0, 0, 0))
base = Image.new('RGBA', (W, H), (0, 0, 0, 0))
base_draw = ImageDraw.Draw(base)
base_draw.rounded_rectangle((0, 0, W, H), radius=54, fill=(245, 136, 30, 255))
img = Image.alpha_composite(img, base)

fruit = Image.new('RGBA', (W, H), (0, 0, 0, 0))
fd = ImageDraw.Draw(fruit)
fd.ellipse((38, 44, 220, 220), fill=(245, 140, 32, 255))
fd.ellipse((90, 80, 170, 150), fill=(255, 221, 171, 90))

leaf = Image.new('RGBA', (W, H), (0, 0, 0, 0))
ld = ImageDraw.Draw(leaf)
ld.ellipse((145, 10, 230, 95), fill=(50, 162, 93, 255))
ld.line((185, 30, 180, 100), fill=(255, 255, 255, 200), width=8)
ld.line((175, 105, 168, 135), fill=(120, 80, 25, 255), width=12)
leaf = leaf.rotate(18, expand=True)
fruit.paste(leaf, (0, 0), leaf)

# face
fd = ImageDraw.Draw(fruit)
fd.ellipse((72, 108, 98, 130), fill=(86, 53, 19, 255))
fd.ellipse((150, 108, 176, 130), fill=(86, 53, 19, 255))
fd.arc((82, 120, 165, 176), start=20, end=160, fill=(88, 55, 15, 255), width=8)

# note page
note = Image.new('RGBA', (W, H), (0, 0, 0, 0))
nd = ImageDraw.Draw(note)
nd.rounded_rectangle((75, 150, 188, 220), radius=12, fill=(252, 245, 210, 255))
nd.polygon([(165, 150), (188, 150), (188, 172)], fill=(236, 229, 190, 255))
for y in range(170, 215, 8):
    nd.line((92, y, 168, y), fill=(242, 171, 63, 255), width=5)
nd.line((92, 160, 152, 160), fill=(242, 171, 63, 255), width=5)

img = Image.alpha_composite(img, fruit)
img = Image.alpha_composite(img, note)
img.save(base_dir / 'orange_note_logo.png')
img.save(base_dir / 'orange_note_logo.ico')
print('Logo criada: orange_note_logo.png / orange_note_logo.ico')

# Build the executable
py_path = r'c:/python313/python.exe'
cmd = [
    py_path,
    '-m',
    'PyInstaller',
    '--onefile',
    '--windowed',
    '--name',
    'Orange Note',
    '--icon',
    str(base_dir / 'orange_note_logo.ico'),
    str(base_dir / 'app.py')
]
print('Compilando EXE...')
result = subprocess.run(cmd, cwd=str(base_dir), capture_output=True, text=True)
print(result.stdout)
print(result.stderr)
if result.returncode != 0:
    raise SystemExit(result.returncode)

exe_path = base_dir / 'dist' / 'Orange Note.exe'
print(f'EXE gerado em: {exe_path}')
print('Atalho desktop será criado em seguida.')
