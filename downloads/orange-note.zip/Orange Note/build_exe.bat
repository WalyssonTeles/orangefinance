@echo off
rem Gera o front-end (React) e o executavel do Orange Notes em dist\Orange Notes\
cd /d "%~dp0"
pushd frontend
call npm install --include=dev || goto :error
call npm run build || goto :error
popd
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean "Orange Notes.spec" || goto :error
echo.
echo Pronto: dist\Orange Notes\Orange Notes.exe
exit /b 0
:error
echo Falha no build.
exit /b 1
