from __future__ import annotations

import ctypes
import sys
from pathlib import Path

import webview

from .api import Api
from .server import LocalServer, frontend_dir
from .storage import APP_DATA_DIR, NoteRepository, ensure_schema
from .window_state import MIN_SIZE, WindowState

APP_ID = "OrangeNotes.App"


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return Path(__file__).resolve().parent.parent


def _icon_path() -> str | None:
    for name in ("orange-note-logo.ico", "orange_note_logo.ico"):
        candidate = _base_dir() / name
        if candidate.is_file():
            return str(candidate)
    return None


def main() -> int:
    ensure_schema()
    repository = NoteRepository()
    repository.purge_empty_notes()

    root = frontend_dir()
    if not (root / "index.html").is_file():
        raise SystemExit(
            f"Front-end não encontrado em {root}. Execute `npm run build` na pasta frontend."
        )
    server = LocalServer(root)
    server.start()

    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    except (AttributeError, OSError):
        pass

    state = WindowState(APP_DATA_DIR / "window.json")
    x, y, width, height = state.geometry()
    window = webview.create_window(
        "Orange Notes",
        server.url,
        js_api=Api(repository, server),
        x=x,
        y=y,
        width=width,
        height=height,
        min_size=MIN_SIZE,
        background_color="#fff8ee",
    )
    state.attach(window)
    webview.start(
        gui="edgechromium",
        storage_path=str(APP_DATA_DIR / "webview"),
        private_mode=False,
        icon=_icon_path(),
    )
    server.shutdown()
    return 0
