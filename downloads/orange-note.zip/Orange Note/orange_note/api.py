"""Ponte entre o front-end (JavaScript) e o armazenamento local."""

from __future__ import annotations

import os
import subprocess
import webbrowser
from datetime import datetime, timezone
from urllib.parse import urlsplit

from .server import ATTACHMENT_NAME_RE, LocalServer
from .storage import (
    ATTACHMENTS_DIR,
    NoteRepository,
    color_to_db,
    color_to_key,
    normalize_content,
)

# Anexos desses tipos nunca são executados: apenas mostrados no Explorer.
UNSAFE_EXTENSIONS = {
    ".exe", ".bat", ".cmd", ".com", ".msi", ".scr", ".ps1", ".psm1", ".vbs", ".vbe",
    ".js", ".jse", ".wsf", ".wsh", ".lnk", ".hta", ".jar", ".reg", ".dll", ".cpl",
}


def _to_epoch_ms(value: str | None) -> int:
    try:
        parsed = datetime.strptime(str(value)[:19], "%Y-%m-%d %H:%M:%S")
        return int(parsed.replace(tzinfo=timezone.utc).timestamp() * 1000)
    except ValueError:
        return int(datetime.now(timezone.utc).timestamp() * 1000)


def _payload(row) -> dict:
    return {
        "id": row["id"],
        "title": row["title"] or "",
        "html": normalize_content(row["content"]),
        "color": color_to_key(row["color"]),
        "updated": _to_epoch_ms(row["updated_at"]),
    }


class Api:
    """Métodos públicos desta classe ficam disponíveis em window.pywebview.api."""

    def __init__(self, repository: NoteRepository, server: LocalServer):
        self._repo = repository
        self._server = server

    def get_token(self) -> str:
        return self._server.token

    def list_notes(self) -> list[dict]:
        return [_payload(row) for row in self._repo.list_notes()]

    def create_note(self, color: str = "butter") -> dict:
        note_id = self._repo.create_note("", "", "Geral", color_to_db(color), at_top=True)
        return _payload(self._repo.get_note(note_id))

    def save_note(self, note_id: int, title: str, html: str, color: str) -> int:
        self._repo.update_note(int(note_id), title, html, "Geral", color_to_db(color))
        return _payload(self._repo.get_note(int(note_id)))["updated"]

    def delete_note(self, note_id: int) -> dict | None:
        row = self._repo.get_note(int(note_id))
        if row is None:
            return None
        snapshot = {key: row[key] for key in row.keys()}
        self._repo.delete_note(int(note_id))
        return snapshot

    def restore_note(self, snapshot: dict) -> dict:
        note_id = self._repo.restore_note(snapshot)
        return _payload(self._repo.get_note(note_id))

    def reorder_notes(self, ordered_ids: list[int]) -> bool:
        known = [row["id"] for row in self._repo.list_notes()]
        wanted = [int(i) for i in ordered_ids if int(i) in known]
        # Notas não mencionadas (ex.: criadas em paralelo) ficam ao final.
        wanted += [i for i in known if i not in wanted]
        self._repo.reorder_notes(wanted)
        return True

    def open_attachment(self, name: str) -> bool:
        if not ATTACHMENT_NAME_RE.match(name):
            return False
        path = ATTACHMENTS_DIR / name
        if not path.is_file():
            return False
        if path.suffix.lower() in UNSAFE_EXTENSIONS:
            subprocess.Popen(["explorer", f"/select,{path}"])
        else:
            os.startfile(path)  # noqa: S606 - abre com o app padrão do Windows
        return True

    def open_url(self, url: str) -> bool:
        parts = urlsplit(url)
        if parts.scheme not in {"http", "https", "mailto"}:
            return False
        webbrowser.open(url)
        return True
