"""Servidor HTTP local (127.0.0.1) que entrega o front-end e os anexos das notas.

Só aceita requisições com Host local e, para envio de arquivos, um token por sessão.
"""

from __future__ import annotations

import json
import mimetypes
import re
import secrets
import sys
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit

from .storage import ATTACHMENTS_DIR

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}
MAX_UPLOAD_BYTES = 200 * 1024 * 1024
ATTACHMENT_NAME_RE = re.compile(r"^[0-9a-f]{32}(\.[a-z0-9]{1,10})?$")


def frontend_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent)) / "frontend"
    return Path(__file__).resolve().parent.parent / "frontend" / "dist"


class _Handler(BaseHTTPRequestHandler):
    server: "LocalServer"
    protocol_version = "HTTP/1.1"

    def log_message(self, format: str, *args) -> None:
        pass

    def _host_ok(self) -> bool:
        return self.headers.get("Host", "") in {
            f"127.0.0.1:{self.server.port}",
            f"localhost:{self.server.port}",
        }

    def _send(self, status: int, body: bytes, content_type: str, extra=None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, status: int, payload: dict) -> None:
        self._send(status, json.dumps(payload).encode(), "application/json")

    def do_GET(self) -> None:
        if not self._host_ok():
            self._send(403, b"forbidden", "text/plain")
            return
        path = unquote(urlsplit(self.path).path)
        if path.startswith("/attachments/"):
            self._serve_attachment(path[len("/attachments/"):])
        else:
            self._serve_frontend(path)

    def _serve_frontend(self, path: str) -> None:
        root = self.server.root.resolve()
        relative = path.lstrip("/") or "index.html"
        target = (root / relative).resolve()
        if root not in target.parents and target != root:
            self._send(403, b"forbidden", "text/plain")
            return
        if not target.is_file():
            self._send(404, b"not found", "text/plain")
            return
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if target.suffix in {".js", ".mjs"}:
            content_type = "text/javascript"
        self._send(200, target.read_bytes(), content_type, {"Cache-Control": "no-cache"})

    def _serve_attachment(self, name: str) -> None:
        if not ATTACHMENT_NAME_RE.match(name):
            self._send(404, b"not found", "text/plain")
            return
        target = ATTACHMENTS_DIR / name
        if not target.is_file():
            self._send(404, b"not found", "text/plain")
            return
        suffix = target.suffix.lower()
        headers = {"Cache-Control": "max-age=31536000, immutable"}
        if suffix in IMAGE_EXTENSIONS:
            content_type = mimetypes.guess_type(target.name)[0] or "image/png"
        else:
            content_type = "application/octet-stream"
            headers["Content-Disposition"] = "attachment"
        self._send(200, target.read_bytes(), content_type, headers)

    def do_POST(self) -> None:
        parsed = urlsplit(self.path)
        if (
            not self._host_ok()
            or parsed.path != "/api/upload"
            or not secrets.compare_digest(
                self.headers.get("X-Orange-Token", ""), self.server.token
            )
        ):
            self._send(403, b"forbidden", "text/plain")
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = -1
        if length < 0 or length > MAX_UPLOAD_BYTES:
            self._json(413, {"error": "Arquivo muito grande (limite de 200 MB)."})
            return

        original = parse_qs(parsed.query).get("name", ["arquivo"])[0]
        suffix = Path(original).suffix.lower()
        if not re.fullmatch(r"\.[a-z0-9]{1,10}", suffix):
            suffix = ""
        name = f"{uuid.uuid4().hex}{suffix}"
        ATTACHMENTS_DIR.mkdir(parents=True, exist_ok=True)
        target = ATTACHMENTS_DIR / name
        remaining = length
        try:
            with open(target, "wb") as output:
                while remaining > 0:
                    chunk = self.rfile.read(min(1024 * 256, remaining))
                    if not chunk:
                        raise OSError("conexão interrompida")
                    output.write(chunk)
                    remaining -= len(chunk)
        except OSError as error:
            target.unlink(missing_ok=True)
            self._json(500, {"error": f"Não foi possível salvar o arquivo: {error}"})
            return
        self._json(
            200,
            {
                "file": name,
                "name": Path(original).name,
                "size": length,
                "kind": "image" if suffix in IMAGE_EXTENSIONS else "file",
            },
        )


class LocalServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, root: Path):
        super().__init__(("127.0.0.1", 0), _Handler)
        self.root = root
        self.port = self.server_address[1]
        self.token = secrets.token_urlsafe(24)

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}/"

    def start(self) -> None:
        threading.Thread(target=self.serve_forever, daemon=True).start()
