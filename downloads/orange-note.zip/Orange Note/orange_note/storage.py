from __future__ import annotations

import html
import os
import re
import shutil
import sqlite3
from contextlib import closing
from html.parser import HTMLParser
from pathlib import Path
from typing import Iterable

PROJECT_DATA_DIR = Path(__file__).resolve().parent.parent / "data"
APP_DATA_DIR = (
    Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming")))
    / "Orange Note"
)
ATTACHMENTS_DIR = APP_DATA_DIR / "attachments"
DB_PATH = APP_DATA_DIR / "orange_note.db"


def _migrate_legacy_db() -> None:
    legacy = PROJECT_DATA_DIR / "orange_note.db"
    if not legacy.exists() or DB_PATH.exists():
        return

    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    try:
        shutil.copy2(legacy, DB_PATH)
    except OSError:
        with closing(sqlite3.connect(legacy)) as source:
            with closing(sqlite3.connect(DB_PATH)) as destination:
                source.backup(destination)


def ensure_schema(db_path: str | Path = DB_PATH) -> None:
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(path)) as connection:
        connection.row_factory = sqlite3.Row
        with connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS notes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    content TEXT NOT NULL,
                    category TEXT DEFAULT 'Geral',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    position INTEGER DEFAULT 0,
                    pinned INTEGER DEFAULT 0,
                    color TEXT DEFAULT '#fff3e6'
                )
                """
            )
            columns = {
                row["name"]
                for row in connection.execute("PRAGMA table_info(notes)")
            }
            migrations = {
                "category": "ALTER TABLE notes ADD COLUMN category TEXT DEFAULT 'Geral'",
                "created_at": "ALTER TABLE notes ADD COLUMN created_at TEXT",
                "updated_at": "ALTER TABLE notes ADD COLUMN updated_at TEXT",
                "position": "ALTER TABLE notes ADD COLUMN position INTEGER DEFAULT 0",
                "pinned": "ALTER TABLE notes ADD COLUMN pinned INTEGER DEFAULT 0",
                "color": "ALTER TABLE notes ADD COLUMN color TEXT DEFAULT '#fff3e6'",
            }
            for column, statement in migrations.items():
                if column not in columns:
                    connection.execute(statement)
            connection.execute(
                "UPDATE notes SET created_at = CURRENT_TIMESTAMP WHERE created_at IS NULL"
            )
            connection.execute(
                "UPDATE notes SET updated_at = CURRENT_TIMESTAMP WHERE updated_at IS NULL"
            )


_migrate_legacy_db()


class _PlainTextExtractor(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"br", "p", "div", "li", "h1", "h2", "h3", "blockquote"}:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in {"p", "div", "li", "h1", "h2", "h3", "blockquote"}:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        self.parts.append(data)


def html_to_text(content: str) -> str:
    extractor = _PlainTextExtractor()
    extractor.feed(content)
    return " ".join(" ".join(extractor.parts).split())


def is_empty_content(content: str | None) -> bool:
    content = content or ""
    return not html_to_text(content) and "<img" not in content and "data-file" not in content


# Chaves de cor do design (Figma) <-> valores salvos no banco.
COLOR_HEX = {
    "butter": "#fdeea0",
    "peach": "#ffd9b8",
    "mint": "#cfeccb",
    "blush": "#ffd0c9",
    "cream": "#ffffff",
}
_HEX_TO_KEY = {value: key for key, value in COLOR_HEX.items()}


def color_to_key(value: str | None) -> str:
    if value in COLOR_HEX:
        return str(value)
    return _HEX_TO_KEY.get((value or "").lower(), "butter")


def color_to_db(value: str | None) -> str:
    return COLOR_HEX[color_to_key(value)]


_BODY_RE = re.compile(r"<body[^>]*>(.*)</body>", re.IGNORECASE | re.DOTALL)


def normalize_content(content: str | None) -> str:
    """Converte conteúdo legado (texto puro ou HTML completo do Qt) para HTML simples."""
    content = content or ""
    stripped = content.lstrip()
    if stripped[:9].lower() == "<!doctype" or stripped[:5].lower() == "<html":
        match = _BODY_RE.search(content)
        text = html_to_text(match.group(1) if match else content)
        return f"<p>{html.escape(text)}</p>" if text else ""
    if not re.search(r"<[a-zA-Z][^>]*>", content):
        return "".join(
            f"<p>{html.escape(line)}</p>" for line in content.splitlines() if line.strip()
        )
    return content


class NoteRepository:
    def __init__(self, db_path: str | Path | None = None):
        self.db_path = Path(db_path or DB_PATH)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        ensure_schema(self.db_path)

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.db_path, timeout=10)
        connection.row_factory = sqlite3.Row
        return connection

    def list_notes(self) -> list[sqlite3.Row]:
        with closing(self._connect()) as connection:
            return connection.execute(
                "SELECT * FROM notes ORDER BY position ASC, updated_at DESC, id ASC"
            ).fetchall()

    def get_note(self, note_id: int) -> sqlite3.Row | None:
        with closing(self._connect()) as connection:
            return connection.execute(
                "SELECT * FROM notes WHERE id = ?", (note_id,)
            ).fetchone()

    def create_note(
        self,
        title: str,
        content: str,
        category: str = "Geral",
        color: str = "#fdeea0",
        at_top: bool = False,
    ) -> int:
        position_sql = (
            "COALESCE((SELECT MIN(position) - 1 FROM notes), 0)"
            if at_top
            else "COALESCE((SELECT MAX(position) + 1 FROM notes), 0)"
        )
        with closing(self._connect()) as connection:
            with connection:
                cursor = connection.execute(
                    f"""
                    INSERT INTO notes
                        (title, content, category, color, created_at, updated_at, position)
                    VALUES
                        (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, {position_sql})
                    """,
                    (title, content, category, color),
                )
                return int(cursor.lastrowid)

    def restore_note(self, note: dict) -> int:
        """Reinsere uma nota excluída (desfazer), mantendo id e posição."""
        with closing(self._connect()) as connection:
            with connection:
                connection.execute(
                    """
                    INSERT OR REPLACE INTO notes
                        (id, title, content, category, color, created_at, updated_at, position)
                    VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?)
                    """,
                    (
                        note["id"],
                        note["title"],
                        note["content"],
                        note.get("category") or "Geral",
                        note["color"],
                        note.get("created_at"),
                        note["position"],
                    ),
                )
        return int(note["id"])

    def purge_empty_notes(self) -> None:
        with closing(self._connect()) as connection:
            rows = connection.execute("SELECT id, title, content FROM notes").fetchall()
            empty = [
                row["id"]
                for row in rows
                if not (row["title"] or "").strip() and is_empty_content(row["content"])
            ]
            with connection:
                connection.executemany(
                    "DELETE FROM notes WHERE id = ?", [(note_id,) for note_id in empty]
                )

    def update_note(
        self,
        note_id: int,
        title: str,
        content: str,
        category: str = "Geral",
        color: str = "#fdeea0",
    ) -> None:
        with closing(self._connect()) as connection:
            with connection:
                cursor = connection.execute(
                    """
                    UPDATE notes
                    SET title = ?, content = ?, category = ?, color = ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """,
                    (title, content, category, color, note_id),
                )
                if cursor.rowcount == 0:
                    raise KeyError(f"Nota {note_id} não encontrada")

    def delete_note(self, note_id: int) -> None:
        with closing(self._connect()) as connection:
            with connection:
                connection.execute("DELETE FROM notes WHERE id = ?", (note_id,))
                self._normalize_positions(connection)

    def move_note(self, note_id: int, new_position: int) -> None:
        ordered_ids = [row["id"] for row in self.list_notes()]
        if note_id not in ordered_ids:
            raise KeyError(f"Nota {note_id} não encontrada")
        ordered_ids.remove(note_id)
        ordered_ids.insert(max(0, min(new_position, len(ordered_ids))), note_id)
        self.reorder_notes(ordered_ids)

    def reorder_notes(self, ordered_ids: Iterable[int]) -> None:
        ids = list(ordered_ids)
        with closing(self._connect()) as connection:
            with connection:
                existing_ids = {
                    row["id"] for row in connection.execute("SELECT id FROM notes")
                }
                if len(ids) != len(set(ids)) or set(ids) != existing_ids:
                    raise ValueError("A ordem precisa incluir cada nota exatamente uma vez")
                for position, note_id in enumerate(ids):
                    connection.execute(
                        "UPDATE notes SET position = ? WHERE id = ?",
                        (position, note_id),
                    )

    @staticmethod
    def _normalize_positions(connection: sqlite3.Connection) -> None:
        rows = connection.execute(
            "SELECT id FROM notes ORDER BY position ASC, updated_at DESC, id ASC"
        ).fetchall()
        for position, row in enumerate(rows):
            connection.execute(
                "UPDATE notes SET position = ? WHERE id = ?", (position, row["id"])
            )
