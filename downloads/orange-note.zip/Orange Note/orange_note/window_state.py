"""Memoriza o tamanho (e a posição horizontal) da janela; ela sempre abre no topo da tela."""

from __future__ import annotations

import ctypes
import json
from ctypes import wintypes
from pathlib import Path
from typing import Any

DEFAULT_SIZE = (1180, 820)
MIN_SIZE = (260, 220)
_FALLBACK_WORK_AREA = (0, 0, 1280, 720)


def work_area() -> tuple[int, int, int, int]:
    """Área útil do monitor principal (sem a barra de tarefas), em pixels lógicos."""
    try:
        user32 = ctypes.windll.user32
        user32.SetProcessDPIAware()
        scale = user32.GetDpiForSystem() / 96
        rect = wintypes.RECT()
        if not user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(rect), 0):  # SPI_GETWORKAREA
            return _FALLBACK_WORK_AREA
        return (
            int(rect.left / scale),
            int(rect.top / scale),
            int(rect.right / scale),
            int(rect.bottom / scale),
        )
    except (AttributeError, OSError):
        return _FALLBACK_WORK_AREA


def _as_int(value: Any) -> int | None:
    return value if isinstance(value, int) and not isinstance(value, bool) else None


class WindowState:
    def __init__(self, path: Path, area: tuple[int, int, int, int] | None = None):
        self._path = path
        self._area = area or work_area()
        saved = self._load()
        self._width = _as_int(saved.get("width"))
        self._height = _as_int(saved.get("height"))
        self._x = _as_int(saved.get("x"))

    def _load(self) -> dict[str, Any]:
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        return data if isinstance(data, dict) else {}

    def geometry(self) -> tuple[int, int, int, int]:
        """Retorna (x, y, largura, altura); y é sempre o topo da área útil."""
        left, top, right, bottom = self._area
        max_w, max_h = right - left, bottom - top
        width = min(max(self._width or DEFAULT_SIZE[0], MIN_SIZE[0]), max_w)
        height = min(max(self._height or DEFAULT_SIZE[1], MIN_SIZE[1]), max_h)
        x = self._x if self._x is not None else left + (max_w - width) // 2
        x = min(max(x, left), right - width)
        return x, top, width, height

    def attach(self, window: Any) -> None:
        window.events.resized += self._on_resized
        window.events.moved += self._on_moved
        window.events.closing += self.save

    def _on_resized(self, width: int, height: int) -> None:
        left, top, right, bottom = self._area
        too_small = width < MIN_SIZE[0] or height < MIN_SIZE[1]
        maximized = width >= right - left and height >= bottom - top
        if not too_small and not maximized:
            self._width, self._height = width, height

    def _on_moved(self, x: int, y: int) -> None:
        left, _, right, _ = self._area
        if left <= x < right - 100:
            self._x = x

    def save(self) -> None:
        data = {"width": self._width, "height": self._height, "x": self._x}
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            temp = self._path.with_suffix(".tmp")
            temp.write_text(json.dumps(data), encoding="utf-8")
            temp.replace(self._path)
        except OSError:
            pass
